Important: Do not edit ./circleci/config.yml directly, since it is a generated file.

Instead, edit files under ./circleci/src and build with `npm run build:ci`, which builds the config file using Mustache.
