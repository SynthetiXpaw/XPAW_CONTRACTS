'use strict';

module.exports = {
	'ExchangeRates.sol': {
		runs: 20000,
	},
	'FeePool.sol': {
		runs: 1500,
	},
};
