'use strict';

const path = require('path');
const { gray, red } = require('chalk');
const pLimit = require('p-limit');
const Deployer = require('../../Deployer');
const NonceManager = require('../../NonceManager');
const { loadCompiledFiles } = require('../../solidity');

const {
	ensureDeploymentPath,
	ensureNetwork,
	getDeploymentPathForNetwork,
	loadAndCheckRequiredSources,
	loadConnections,
	reportDeployedContracts,
} = require('../../util');
const { performTransactionalStep } = require('../../command-utils/transact');

const {
	constants: { BUILD_FOLDER, CONFIG_FILENAME, SYNTHS_FILENAME, DEPLOYMENT_FILENAME },
} = require('../../../..');

const addSynthsToProtocol = require('./add-synths-to-protocol');
const configureLegacySettings = require('./configure-legacy-settings');
const configureRewardEscrow = require('./configure-reward-escrow');
const configureLoans = require('./configure-loans');
const configureStandalonePriceFeeds = require('./configure-standalone-price-feeds');
const configureOffchainPriceFeeds = require('./configure-offchain-price-feeds');
const configureSynths = require('./configure-synths');
const configureFutures = require('./configure-futures');
const configurePerpsV2 = require('./configure-perpsv2');
const configureSystemSettings = require('./configure-system-settings');
const deployCore = require('./deploy-core');
const deployDappUtils = require('./deploy-dapp-utils.js');
const deployLoans = require('./deploy-loans');
const deploySynths = require('./deploy-synths');
const deployFutures = require('./deploy-futures');
const deployPerpsV2 = require('./deploy-perpsv2');
const generateSolidityOutput = require('./generate-solidity-output');
const getDeployParameterFactory = require('./get-deploy-parameter-factory');
const importAddresses = require('./import-addresses');
const importFeePeriods = require('./import-fee-periods');
const importExcludedDebt = require('./import-excluded-debt');
const performSafetyChecks = require('./perform-safety-checks');
const rebuildResolverCaches = require('./rebuild-resolver-caches');
const rebuildLegacyResolverCaches = require('./rebuild-legacy-resolver-caches');
const systemAndParameterCheck = require('./system-and-parameter-check');
// const takeDebtSnapshotWhenRequired = require('./take-debt-snapshot-when-required');

const DEFAULTS = {
	priorityGasPrice: '1',
	debtSnapshotMaxDeviation: 0.01, // a 1 percent deviation will trigger a snapshot
	network: 'goerli',
	buildPath: path.join(__dirname, '..', '..', '..', '..', BUILD_FOLDER),
};

const deploy = async ({
	addNewSynths,
	buildPath = DEFAULTS.buildPath,
	concurrency,
	deploymentPath,
	dryRun = false,
	freshDeploy,
	maxFeePerGas,
	maxPriorityFeePerGas = DEFAULTS.priorityGasPrice,
	generateSolidity = false,
	ignoreCustomParameters,
	ignoreSafetyChecks,
	manageNonces,
	network = DEFAULTS.network,
	privateKey,
	signer,
	providerUrl,
	provider,
	skipFeedChecks = false,
	specifyContracts,
	useFork,
	useOvm,
	yes,
	includeFutures = false,
	includePerpsV2 = false,
} = {}) => {
	ensureNetwork(network);
	deploymentPath = deploymentPath || getDeploymentPathForNetwork({ network, useOvm });
	ensureDeploymentPath(deploymentPath);

	const limitPromise = pLimit(concurrency);

	const {
		config,
		params,
		configFile,
		synths,
		deployment,
		deploymentFile,
		ownerActions,
		ownerActionsFile,
		feeds,
		offchainFeeds,
	} = loadAndCheckRequiredSources({
		deploymentPath,
		network,
		freshDeploy,
	});

	const getDeployParameter = getDeployParameterFactory({ params, ignoreCustomParameters });

	const addressOf = c => (c ? c.address : '');
	const sourceOf = c => (c ? c.source : '');

	// Mark contracts for deployment specified via an argument
	if (specifyContracts) {
		// Ignore config.json
		Object.keys(config).map(name => {
			config[name].deploy = false;
		});
		// Add specified contracts
		specifyContracts.split(',').map(name => {
			if (!config[name]) {
				config[name] = {
					deploy: true,
				};
			} else {
				config[name].deploy = true;
			}
		});
	}

	performSafetyChecks({
		config,
		deployment,
		deploymentPath,
		freshDeploy,
		ignoreSafetyChecks,
		manageNonces,
		maxFeePerGas,
		maxPriorityFeePerGas,
		network,
		useOvm,
	});

	console.log(
		gray('Checking all contracts not flagged for deployment have addresses in this network...')
	);
	const missingDeployments = Object.keys(config).filter(name => {
		return !config[name].deploy && (!deployment.targets[name] || !deployment.targets[name].address);
	});

	if (missingDeployments.length) {
		throw Error(
			`Cannot use existing contracts for deployment as addresses not found for the following contracts on ${network}:\n` +
				missingDeployments.join('\n') +
				'\n' +
				gray(`Used: ${deploymentFile} as source`)
		);
	}

	console.log(gray('Loading the compiled contracts locally...'));
	const { earliestCompiledTimestamp, compiled } = loadCompiledFiles({ buildPath });

	const { privateKey: envPrivateKey, explorerLinkPrefix } = loadConnections({
		network,
		useFork,
		useOvm,
	});

	// Here we set a default private key for local-ovm deployment, as the
	// OVM geth node has no notion of local/unlocked accounts.
	// Deploying without a private key will give the error "OVM: Unsupported RPC method",
	// as the OVM node does not support eth_sendTransaction, which inherently relies on
	// the unlocked accounts on the node.
	if (network === 'local' && useOvm && !privateKey) {
		// Account #0: 0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266
		privateKey = '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80';
	}

	// when not in a local network, and not forking, and the privateKey isn't supplied,
	// use the one from the .env file
	if (network !== 'local' && !useFork && !privateKey) {
		privateKey = envPrivateKey;
	}

	const nonceManager = new NonceManager({});

	const deployer = new Deployer({
		account: signer ? await signer.getAddress() : null,
		compiled,
		config,
		configFile,
		deployment,
		deploymentFile,
		maxFeePerGas,
		maxPriorityFeePerGas,
		network,
		privateKey,
		signer,
		providerUrl,
		provider,
		dryRun,
		useOvm,
		useFork,
		nonceManager: manageNonces ? nonceManager : undefined,
	});

	const { account } = deployer;

	if (!signer) {
		signer = deployer.signer;
	}

	nonceManager.provider = deployer.provider;
	nonceManager.account = account;

	const {
		currentSynthetixSupply,
		currentLastMintEvent,
		currentWeekOfInflation,
		systemSuspended,
	} = await systemAndParameterCheck({
		account,
		buildPath,
		addNewSynths,
		concurrency,
		config,
		deployer,
		deploymentPath,
		dryRun,
		earliestCompiledTimestamp,
		freshDeploy,
		maxFeePerGas,
		maxPriorityFeePerGas,
		getDeployParameter,
		network,
		skipFeedChecks,
		feeds,
		synths,
		providerUrl,
		useFork,
		useOvm,
		yes,
	});

	console.log(
		gray(`Starting deployment to ${network.toUpperCase()}${useFork ? ' (fork)' : ''}...`)
	);

	// track for use with solidity output
	const runSteps = [];

	const runStep = async (opts, overrides) => {
		const { noop, ...rest } = await performTransactionalStep({
			...opts,
			signer,
			dryRun,
			explorerLinkPrefix,
			maxFeePerGas,
			maxPriorityFeePerGas,
			generateSolidity,
			nonceManager: manageNonces ? nonceManager : undefined,
			ownerActions,
			ownerActionsFile,
			useFork,
			...overrides,
		});

		// only add to solidity steps when the transaction is NOT a no-op
		if (!noop) {
			runSteps.push(opts);
		}

		return { noop, ...rest };
	};

	await deployCore({
		account,
		addressOf,
		currentLastMintEvent,
		currentSynthetixSupply,
		currentWeekOfInflation,
		deployer,
		useOvm,
	});

	const { synthsToAdd } = await deploySynths({
		account,
		addressOf,
		addNewSynths,
		config,
		deployer,
		freshDeploy,
		deploymentPath,
		generateSolidity,
		network,
		synths,
		systemSuspended,
		useFork,
		yes,
	});

	const { collateralManagerDefaults } = await deployLoans({
		account,
		addressOf,
		deployer,
		getDeployParameter,
		network,
		useOvm,
	});

	console.log(gray(`\n------ DEPLOY FUTURES MARKETS MANAGER (Legacy and PerpsV2) ------\n`));

	const { ReadProxyAddressResolver } = deployer.deployedContracts;
	const futuresMarketManager = await deployer.deployContract({
		name: 'FuturesMarketManager',
		source: useOvm ? 'FuturesMarketManager' : 'EmptyFuturesMarketManager',
		args: useOvm ? [account, addressOf(ReadProxyAddressResolver)] : [],
		deps: ['ReadProxyAddressResolver'],
	});

	if (includeFutures) {
		await deployFutures({
			account,
			addressOf,
			getDeployParameter,
			deployer,
			runStep,
			useOvm,
			network,
			deploymentPath,
			loadAndCheckRequiredSources,
			futuresMarketManager,
		});
	} else {
		console.log(gray(`\n------ EXCLUDE FUTURES MARKETS ------\n`));
	}

	if (includePerpsV2) {
		await deployPerpsV2({
			account,
			addressOf,
			getDeployParameter,
			deployer,
			runStep,
			useOvm,
			network,
			deploymentPath,
			loadAndCheckRequiredSources,
			futuresMarketManager,
		});
	} else {
		console.log(gray(`\n------ EXCLUDE PERPS V2 MARKETS ------\n`));
	}

	await deployDappUtils({
		account,
		addressOf,
		deployer,
	});

	const { newContractsBeingAdded } = await importAddresses({
		addressOf,
		deployer,
		dryRun,
		continueEvenIfUnsuccessful: generateSolidity,
		limitPromise,
		runStep,
	});

	await rebuildResolverCaches({
		deployer,
		generateSolidity,
		limitPromise,
		newContractsBeingAdded,
		runStep,
		network,
		useOvm,
	});

	await rebuildLegacyResolverCaches({
		addressOf,
		compiled,
		deployer,
		network,
		runStep,
		useOvm,
	});

	await configureLegacySettings({
		account,
		addressOf,
		config,
		deployer,
		getDeployParameter,
		network,
		runStep,
		useOvm,
	});

	await configureRewardEscrow({
		addressOf,
		deployer,
		runStep,
		useOvm,
	});

	await importFeePeriods({
		deployer,
		explorerLinkPrefix,
		freshDeploy,
		generateSolidity,
		network,
		runStep,
		systemSuspended,
		useFork,
		yes,
	});

	await importExcludedDebt({
		deployer,
		freshDeploy,
		runStep,
	});

	// Configure all feeds as standalone in case they are being used as synth currency keys (through synth),
	// or directly (e.g. futures). Adding just one or the other may cause issues if e.g. initially futures
	// market exists, but later a synth is added. Or if initially both exist, but later the spot synth
	// is removed. The standalone feed should always be added and available.
	await configureStandalonePriceFeeds({
		deployer,
		runStep,
		feeds,
		useOvm,
	});

	if (includePerpsV2) {
		await configureOffchainPriceFeeds({
			deployer,
			runStep,
			offchainFeeds,
			useOvm,
		});
	}

	await configureSynths({
		addressOf,
		explorerLinkPrefix,
		generateSolidity,
		feeds,
		deployer,
		network,
		runStep,
		synths,
	});

	await addSynthsToProtocol({
		addressOf,
		deployer,
		runStep,
		synthsToAdd,
	});

	await configureSystemSettings({
		addressOf,
		deployer,
		useOvm,
		generateSolidity,
		getDeployParameter,
		network,
		runStep,
		synths,
	});

	await configureLoans({
		addressOf,
		collateralManagerDefaults,
		deployer,
		getDeployParameter,
		runStep,
	});

	if (includeFutures) {
		await configureFutures({
			addressOf,
			deployer,
			loadAndCheckRequiredSources,
			runStep,
			getDeployParameter,
			useOvm,
			freshDeploy,
			deploymentPath,
			network,
			generateSolidity,
			yes,
		});
	}

	if (includePerpsV2) {
		await configurePerpsV2({
			addressOf,
			deployer,
			loadAndCheckRequiredSources,
			runStep,
			getDeployParameter,
			useOvm,
			freshDeploy,
			deploymentPath,
			network,
			generateSolidity,
			yes,
		});
	}

	// await takeDebtSnapshotWhenRequired({
	// 	debtSnapshotMaxDeviation: DEFAULTS.debtSnapshotMaxDeviation,
	// 	deployer,
	// 	generateSolidity,
	// 	runStep,
	// 	useOvm,
	// 	useFork,
	// });

	console.log(gray(`\n------ DEPLOY COMPLETE ------\n`));

	reportDeployedContracts({ deployer });

	if (generateSolidity) {
		generateSolidityOutput({
			addressOf,
			deployer,
			deployment,
			explorerLinkPrefix,
			network,
			newContractsBeingAdded,
			runSteps,
			sourceOf,
			useOvm,
		});
	}
};

module.exports = {
	deploy,
	DEFAULTS,
	cmd: program =>
		program
			.command('deploy')
			.description('Deploy compiled solidity files')
			.option(
				'-a, --add-new-synths',
				`Whether or not any new synths in the ${SYNTHS_FILENAME} file should be deployed if there is no entry in the config file`,
				true
			)
			.option(
				'-b, --build-path [value]',
				'Path to a folder hosting compiled files from the "build" step in this script',
				DEFAULTS.buildPath
			)
			.option(
				'-d, --deployment-path <value>',
				`Path to a folder that has your input configuration file ${CONFIG_FILENAME}, the synth list ${SYNTHS_FILENAME} and where your ${DEPLOYMENT_FILENAME} files will go`
			)
			.option(
				'-e, --concurrency <value>',
				'Number of parallel calls that can be made to a provider',
				10
			)
			.option(
				'-f, --fee-auth <value>',
				'The address of the fee authority for this network (default is to use existing)'
			)
			.option('-g, --max-fee-per-gas <value>', 'Maximum base gas fee price in GWEI')
			.option(
				'--max-priority-fee-per-gas <value>',
				'Priority gas fee price in GWEI',
				DEFAULTS.priorityGasPrice
			)
			.option('--generate-solidity', 'Whether or not to output the migration as a Solidity file')
			.option(
				'-h, --fresh-deploy',
				'Perform a "fresh" deploy, i.e. the first deployment on a network.'
			)
			.option(
				'-i, --ignore-safety-checks',
				'Ignores some validations regarding paths, compiler versions, etc.',
				false
			)
			.option(
				'--ignore-custom-parameters',
				'Ignores deployment parameters specified in params.json',
				false
			)
			.option(
				'-k, --use-fork',
				'Perform the deployment on a forked chain running on localhost (see fork command).',
				false
			)
			.option(
				'-l, --oracle-gas-limit <value>',
				'The address of the gas limit oracle for this network (default is use existing)'
			)
			.option(
				'-n, --network <value>',
				'The network to run off.',
				x => x.toLowerCase(),
				DEFAULTS.network
			)
			.option(
				'-o, --oracle-exrates <value>',
				'The address of the oracle for this network (default is use existing)'
			)
			.option(
				'-q, --manage-nonces',
				'The command makes sure that no repeated nonces are sent (which may be the case when reorgs are common, i.e. in Goerli. Not to be confused with --manage-nonsense.)',
				false
			)
			.option(
				'-p, --provider-url <value>',
				'Ethereum network provider URL. If default, will use PROVIDER_URL found in the .env file.'
			)
			.option(
				'--skip-feed-checks',
				'If enabled, will skip the feed checking on start (speeds up deployment)'
			)
			.option(
				'-r, --dry-run',
				'If enabled, will not run any transactions but merely report on them.'
			)
			.option(
				'-v, --private-key [value]',
				'The private key to deploy with (only works in local mode, otherwise set in .env).'
			)
			.option(
				'-x, --specify-contracts <value>',
				'Ignore config.json  and specify contracts to be deployed (Comma separated list)'
			)
			.option('--include-future', 'Include legacy Futures (deployment and configuration)')
			.option(
				'--include-perps-v2',
				'Include PerpsV2 (deployment, configuration and offchain feeds)'
			)
			.option('-y, --yes', 'Dont prompt, just reply yes.')
			.option('-z, --use-ovm', 'Target deployment for the OVM (Optimism).')
			.action(async (...args) => {
				try {
					await deploy(...args);
				} catch (err) {
					// show pretty errors for CLI users
					console.error(red(err));
					console.log(err.stack);
					process.exitCode = 1;
				}
			}),
};
