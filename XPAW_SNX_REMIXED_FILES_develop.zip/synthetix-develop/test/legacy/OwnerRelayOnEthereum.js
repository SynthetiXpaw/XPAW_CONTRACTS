const chalk = require('chalk');
const { ethers, contract, artifacts } = require('hardhat');
const { assert } = require('../contracts/common');
const { smock } = require('@defi-wonderland/smock');
const { ensureOnlyExpectedMutativeFunctions } = require('../contracts/helpers');
const {
	defaults: { CROSS_DOMAIN_RELAY_GAS_LIMIT },
} = require('../..');

contract('OwnerRelayOnEthereum', () => {
	// Signers
	let owner, user;

	// Real contracts
	let OwnerRelayOnEthereum;

	// Mocked contracts
	let MockedMessenger, MockedAddressResolver, MockedFlexibleStorage, MockedOwnerRelayOnOptimism;

	// Other mocked stuff
	const mockedOwnerRelayOnOptimismAddress = ethers.Wallet.createRandom().address;
	const mockedContractAddressOnL2 = ethers.Wallet.createRandom().address;
	const mockedRelayData = '0xdeadbeef';

	before('initialize signers', async () => {
		[owner, user] = await ethers.getSigners();
	});

	before('mock other contracts used by OwnerRelayOnEthereum', async () => {
		MockedMessenger = await smock(
			artifacts.require('iAbs_BaseCrossDomainMessenger').abi,
			ethers.provider
		);

		MockedOwnerRelayOnOptimism = await smock(
			artifacts.require('OwnerRelayOnOptimism').abi,
			ethers.provider
		);

		MockedFlexibleStorage = await smock.fake('FlexibleStorage', ethers.provider);

		MockedAddressResolver = await smock.fake('AddressResolver', ethers.provider);
		MockedAddressResolver.requireAndGetAddress.returns(nameBytes => {
			const name = ethers.utils.toUtf8String(nameBytes);

			if (name.includes('ext:Messenger')) {
				return MockedMessenger.address;
			} else if (name.includes('FlexibleStorage')) {
				return MockedFlexibleStorage.address;
			} else if (name.includes('ovm:OwnerRelayOnOptimism')) {
				return mockedOwnerRelayOnOptimismAddress;
			} else {
				console.log(chalk.red(`Mocked AddressResolver will not be able to resolve ${name}`));
			}
		});
	});

	before('instantiate the contract', async () => {
		const OwnerRelayOnEthereumFactory = await ethers.getContractFactory(
			'OwnerRelayOnEthereum',
			owner
		);
		OwnerRelayOnEthereum = await OwnerRelayOnEthereumFactory.deploy(
			owner.address,
			MockedAddressResolver.address
		);

		const tx = await OwnerRelayOnEthereum.rebuildCache();
		await tx.wait();
	});

	it('requires the expected contracts', async () => {
		const requiredAddresses = await OwnerRelayOnEthereum.resolverAddressesRequired();

		assert.equal(requiredAddresses.length, 3);
		assert.ok(requiredAddresses.includes(ethers.utils.formatBytes32String('FlexibleStorage')));
		assert.ok(requiredAddresses.includes(ethers.utils.formatBytes32String('ext:Messenger')));
		assert.ok(
			requiredAddresses.includes(ethers.utils.formatBytes32String('ovm:OwnerRelayOnOptimism'))
		);
	});

	it('shows that only the expected functions are mutative', async () => {
		ensureOnlyExpectedMutativeFunctions({
			abi: artifacts.require('OwnerRelayOnEthereum').abi,
			ignoreParents: ['Owned', 'MixinResolver'],
			expected: ['initiateRelay', 'initiateRelayBatch'],
		});
	});

	describe('when attempting to initiate a relay from a non-owner account', () => {
		it('reverts with the expected error', async () => {
			await assert.revert(
				OwnerRelayOnEthereum.connect(user).initiateRelay(
					mockedContractAddressOnL2,
					mockedRelayData,
					0
				),
				'Only the contract owner may perform this action'
			);
		});
	});

	describe('when attempting to initiate a relay batch from a non-owner account', () => {
		it('reverts with the expected error', async () => {
			const mockedTargets = [mockedContractAddressOnL2, mockedContractAddressOnL2];
			const mockedRelayBatchData = [mockedRelayData, mockedRelayData];
			await assert.revert(
				OwnerRelayOnEthereum.connect(user).initiateRelayBatch(
					mockedTargets,
					mockedRelayBatchData,
					0
				),
				'Only the contract owner may perform this action'
			);
		});
	});

	describe('when attempting to initiate a relay batch from an owner account but there is argument inconsistency', () => {
		it('reverts with the expected error', async () => {
			const mockedTargets = [mockedContractAddressOnL2, mockedContractAddressOnL2];
			const mockedRelayBatchData = [mockedRelayData];
			await assert.revert(
				OwnerRelayOnEthereum.connect(owner).initiateRelayBatch(
					mockedTargets,
					mockedRelayBatchData,
					0
				),
				'Argument length mismatch'
			);
		});
	});

	describe('when relaying from the owner account', () => {
		let relayReceipt, relayBatchReceipt;

		const specifiedCrossDomainRelayGasLimit = 3e6;

		let relayedMessage = {
			contractOnL2: undefined,
			messageData: undefined,
			crossDomainGasLimit: undefined,
		};

		before('mock SystemSettings.getCrossDomainMessageGasLimit(...)', async () => {
			MockedFlexibleStorage.getUIntValue.returns((contractNameBytes, valueNameBytes) => {
				const contractName = ethers.utils.toUtf8String(contractNameBytes);
				const valueName = ethers.utils.toUtf8String(valueNameBytes);

				if (
					contractName.includes('SystemSettings') &&
					valueName.includes('crossDomainRelayGasLimit')
				) {
					return CROSS_DOMAIN_RELAY_GAS_LIMIT;
				} else {
					console.log(
						chalk.red(
							`Mocked FlexibleStorage will not be able to resolve ${contractName}:${valueName}`
						)
					);
				}
			});
		});

		before('mock Optimism Messenger.sendMessage(...)', async () => {
			// Allows us to record what Messenger.sendMessage gets called with
			MockedMessenger.sendMessage.returns((contractOnL2, messageData, crossDomainGasLimit) => {
				relayedMessage = { contractOnL2, messageData, crossDomainGasLimit };
			});
		});

		describe('when initiating a single relay', () => {
			before('initiate the relay', async () => {
				const tx = await OwnerRelayOnEthereum.connect(owner).initiateRelay(
					mockedContractAddressOnL2,
					mockedRelayData,
					specifiedCrossDomainRelayGasLimit
				);
				relayReceipt = await tx.wait();
			});

			it('relayed a message to OwnerRelayOnOptimism', async () => {
				assert.equal(relayedMessage.contractOnL2, mockedOwnerRelayOnOptimismAddress);
			});

			it('relayed the message with the expected crossDomainGasLimit', async () => {
				assert.equal(relayedMessage.crossDomainGasLimit, specifiedCrossDomainRelayGasLimit);
			});

			it('relayed the correct data', async () => {
				const expectedRelayData = MockedOwnerRelayOnOptimism.interface.encodeFunctionData(
					'finalizeRelay',
					[mockedContractAddressOnL2, mockedRelayData]
				);

				assert.equal(relayedMessage.messageData, expectedRelayData);
			});

			it('emited a RelayInitiated event', async () => {
				const event = relayReceipt.events.find(e => e.event === 'RelayInitiated');

				assert.equal(event.args.target, mockedContractAddressOnL2);
				assert.equal(event.args.payload, mockedRelayData);
			});

			describe('when not specifying a cross domain relay gas limit', () => {
				before('initiate the relay', async () => {
					const tx = await OwnerRelayOnEthereum.connect(owner).initiateRelay(
						mockedContractAddressOnL2,
						mockedRelayData,
						0
					);
					await tx.wait();
				});

				it('relayed the message with the default crossDomainGasLimit', async () => {
					assert.equal(relayedMessage.crossDomainGasLimit, CROSS_DOMAIN_RELAY_GAS_LIMIT);
				});
			});
		});

		describe('when initiating a relay batch', () => {
			const mockedTargets = [mockedContractAddressOnL2, mockedContractAddressOnL2];
			const mockedRelayBatchData = [mockedRelayData, mockedRelayData];
			before('initiate the relay', async () => {
				const tx = await OwnerRelayOnEthereum.connect(owner).initiateRelayBatch(
					mockedTargets,
					mockedRelayBatchData,
					specifiedCrossDomainRelayGasLimit
				);
				relayBatchReceipt = await tx.wait();
			});

			it('relayed a message to OwnerRelayOnOptimism', async () => {
				assert.equal(relayedMessage.contractOnL2, mockedOwnerRelayOnOptimismAddress);
			});

			it('relayed the message with the expected crossDomainGasLimit', async () => {
				assert.equal(relayedMessage.crossDomainGasLimit, specifiedCrossDomainRelayGasLimit);
			});

			it('relayed the correct data', async () => {
				const expectedRelayData = MockedOwnerRelayOnOptimism.interface.encodeFunctionData(
					'finalizeRelayBatch',
					[mockedTargets, mockedRelayBatchData]
				);

				assert.equal(relayedMessage.messageData, expectedRelayData);
			});

			it('emited a RelayBatchInitiated event', async () => {
				const event = relayBatchReceipt.events.find(e => e.event === 'RelayBatchInitiated');

				assert.deepEqual(event.args.targets, mockedTargets);
				assert.deepEqual(event.args.payloads, mockedRelayBatchData);
			});

			describe('when not specifying a cross domain relay gas limit', () => {
				before('initiate the relay batch', async () => {
					const tx = await OwnerRelayOnEthereum.connect(owner).initiateRelayBatch(
						mockedTargets,
						mockedRelayBatchData,
						0
					);
					await tx.wait();
				});

				it('relayed the message with the default crossDomainGasLimit', async () => {
					assert.equal(relayedMessage.crossDomainGasLimit, CROSS_DOMAIN_RELAY_GAS_LIMIT);
				});
			});
		});
	});
});
